package com.example.demo.interceptor;

import com.example.demo.Constant;
import com.example.demo.annotation.BucketAnnotation;
import com.example.demo.annotation.UrlAnnotation;
import com.example.demo.exception.APIException;
import com.example.demo.utils.BucketUtil;
import com.example.demo.utils.RedisUtils;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;

/**
 * 权限管理URL拦截器
 */
public class URLInterceptor implements HandlerInterceptor {

    // 预处理回调方法，在接口调用之前使用  true代表放行  false代表不放行
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        String token = httpServletRequest.getHeader("token");
        String requestURL = httpServletRequest.getRequestURI();
        //截取URL前面 对应的模块
        String[] split=requestURL.split("/");
        if(split[1]==null){
            throw new APIException("url format error");
        }
        //获取到对应的注解上面的type 获取不到默认无权限
//        HandlerMethod handlerMethod = (HandlerMethod) handler;
//        Method method = handlerMethod.getMethod();
//        UrlAnnotation urlAnnotation = method.getAnnotation(UrlAnnotation.class);
//        if(urlAnnotation==null){
//            throw  new APIException("当前用户没有访问路径" + requestURL + "的权限");
//        }
//        String type = urlAnnotation.type();
        //1.根据token判断用户是否登录
        if (token==null){   //正常情况下这里还需判断与redis中的token是否匹配
            // 如果没有token或者token不匹配, 直接抛出异常  提示未登录
            throw  new APIException("当前用户未登录");
        }
        //2.登录成功后 根据用户token中的信息获取到用户对应的URL权限集合

        String[] strings = Constant.permission.get(Integer.valueOf(token));
        boolean hasPermission = false;
        //3.再根据用户对应的URL集合去与当前请求的URL对比  有匹配的则放行  反之则抛出异常
        for (int i =0;i<strings.length;i++) {
            if (strings[i].equals(split[1])){
                hasPermission = true;
                break;
            }
        }
        if (hasPermission){
            return true;
        }else {
            throw  new APIException("当前用户没有访问路径" + requestURL + "的权限");
        }
    }
}
