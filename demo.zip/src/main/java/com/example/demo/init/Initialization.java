package com.example.demo.init;


import com.example.demo.service.InsertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class Initialization implements CommandLineRunner {
    @Autowired
    private InsertService dataMergeService;
    @Override
    public void run(String... args) {
        //数据转移
//        dataMergeService.dataMerge();
        //数据拷贝
//        dataMergeService.listInsertDemo();
    }

}
