package com.example.demo.controller;

import com.example.demo.annotation.UrlAnnotation;
import com.example.demo.utils.JWTUtil;
import com.example.demo.utils.RedisUtils;
import com.example.demo.vo.ResultVO;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@RequestMapping(value = "/shiro")
public class ShiroController {

    @RequestMapping(value = "/test/url1")
    public String url1() {
        return "恭喜你，你有此权限";
    }
    @RequestMapping(value = "/test/url2")
    public String url2() {
        return "恭喜你，你有此权限";
    }
    @RequestMapping(value = "/test1/url3")
    public String url3() {
        return "恭喜你，你有此权限";
    }
    @RequestMapping(value = "/test1/url4")
    public String url4() {
        return "恭喜你，你有此权限";
    }

}
