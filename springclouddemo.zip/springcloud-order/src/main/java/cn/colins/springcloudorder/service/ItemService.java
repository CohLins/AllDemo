package cn.colins.springcloudorder.service;

import cn.colins.springcloudorder.mdoel.Item;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

public interface ItemService {


    Item queryItemById(Long id);

}
