package com.example.demo.service;

import com.example.demo.vo.ResultVO;

/**
 * @program: demo
 * @description: 批量插入判断字段非空demo
 * @author: colins
 * @create: 2020-12-04 09:20
 **/
public interface InsertService {
    /**
     * @Author colins
     * @Description 批量插入demo 事务验证
     * @Date 2020/12/4 9:21
     * @Param []
     * @return com.example.demo.vo.ResultVO
     **/
    ResultVO listInsertDemo();
}