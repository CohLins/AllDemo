package com.example.demo.serviceImpl;

import com.example.demo.mapper.UserMapper;
import com.example.demo.model.User;
import com.example.demo.service.DemoService;
import com.example.demo.utils.E3Result;
import org.apache.poi.POIXMLDocumentPart;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;
import org.openxmlformats.schemas.drawingml.x2006.spreadsheetDrawing.CTMarker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DemoServiceImpl implements DemoService {
    private static Map<String, String> pictureMap=new HashMap<>();//这个用来存放图片路径的

    private Workbook workbook;

    @Autowired
    private UserMapper userMapper;


    public E3Result getExcel(MultipartFile file) throws Exception {
//        1、判断表格是xlsx格式还是xls格式
        if (StringUtils.endsWithIgnoreCase(file.getOriginalFilename(), "xlsx")) {
            workbook = new XSSFWorkbook(file.getInputStream());
            System.out.println("表格是xlsx格式");
        } else if (StringUtils.endsWithIgnoreCase(file.getOriginalFilename(), "xls")) {
            workbook = new HSSFWorkbook(file.getInputStream());
            System.out.println("表格是xls格式");
        } else {
            return E3Result.build(400,"文件类型不符合");
        }

//        2、根据文件类型读取Excel全图片 文件类型不同读取方式不同
        if (StringUtils.endsWithIgnoreCase(file.getOriginalFilename(), "xlsx")) {
            getPicturesXLSX(workbook);
        } else {
            getPicturesXLS(workbook);
        }
//        3、获取第一张工作表
        Sheet sheet = workbook.getSheetAt(0);
//        4、获取行数
        int rowNum = sheet.getLastRowNum();

//        5、遍历每一行  第一行表头跳过
        for (int i = 1; i <= rowNum; i++) {
            Row row = sheet.getRow(i);
            //row.getCell(2) 这个是获取第几列 例如这里就是第三列 下标从0开始
            //getCellValue是自动判断表格数据并转成String返回
            //6.获取到数据填充到实体类插入
            User user = new User();
            user.setId(null);
            user.setName(getCellValue(row.getCell(2)));
            user.setAge(Integer.valueOf(getCellValue(row.getCell(3))));
            user.setSex(getCellValue(row.getCell(4)));
            user.setAddress(getCellValue(row.getCell(5)));
            user.setCreateTime(new Date());
            user.setUpdateTime(new Date());
            //这里获取图片的路径
            user.setPicUrl(pictureMap.get(i+"+"+1));
            //7.插入
            userMapper.insertData(user);
        }
        return E3Result.ok();
    }



    /**
     * cell数据格式转换
     *
     * @param cell
     * @return
     */
    public String getCellValue(Cell cell) {
        switch (cell.getCellType()) {
            case Cell.CELL_TYPE_NUMERIC: // 数字
                //如果为时间格式的内容
                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                    //注：format格式 yyyy-MM-dd hh:mm:ss 中小时为12小时制，若要24小时制，则把小h变为H即可，yyyy-MM-dd HH:mm:ss
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                    return sdf.format(HSSFDateUtil.getJavaDate(cell.
                            getNumericCellValue())).toString();
                } else {
                    return new DecimalFormat("0").format(cell.getNumericCellValue());
                }
            case Cell.CELL_TYPE_STRING: // 字符串
                return cell.getStringCellValue();
            case Cell.CELL_TYPE_BOOLEAN: // Boolean
                return cell.getBooleanCellValue() + "";
            case Cell.CELL_TYPE_FORMULA: // 公式
                return cell.getCellFormula() + "";
            case Cell.CELL_TYPE_BLANK: // 空值
                return "";
            case Cell.CELL_TYPE_ERROR: // 故障
                return null;
            default:
                return null;
        }
    }

    /**
     * 获取Excel2003的图片
     *
     * @param workbook
     */
    public void getPicturesXLS(Workbook workbook) throws IOException {
        List<HSSFPictureData> pictures = (List<HSSFPictureData>) workbook.getAllPictures();
        HSSFSheet sheet = (HSSFSheet) workbook.getSheetAt(0);
        if (pictures.size() != 0) {
            for (HSSFShape shape : sheet.getDrawingPatriarch().getChildren()) {
                HSSFClientAnchor anchor = (HSSFClientAnchor) shape.getAnchor();
                //获取图片对应所在行
                Row row=sheet.getRow(anchor.getRow1());
                if (shape instanceof HSSFPicture) {
                    HSSFPicture pic = (HSSFPicture) shape;
                    int pictureIndex = pic.getPictureIndex() - 1;
                    HSSFPictureData picData = pictures.get(pictureIndex);
                    //以图片所在行列为键值，以图片路径为value值存取
                    //printImg（）是将图片数据及图片名称传入，保存图片   这里我的图片名称为"_+人名"  返回图片路径
                    pictureMap.put(anchor.getRow1()+"+"+anchor.getCol1(), printImg(picData,"_"+getCellValue(row.getCell(2))));
                }
            }
        }
    }

    /**
     * 获取Excel2007的图片
     *
     * @param workbook
     */
    public void getPicturesXLSX(Workbook workbook) throws IOException {
        XSSFSheet xssfSheet = (XSSFSheet) workbook.getSheetAt(0);
        for (POIXMLDocumentPart dr : xssfSheet.getRelations()) {
            if (dr instanceof XSSFDrawing) {
                XSSFDrawing drawing = (XSSFDrawing) dr;
                List<XSSFShape> shapes = drawing.getShapes();
                for (XSSFShape shape : shapes) {
                    XSSFPicture pic = (XSSFPicture) shape;
                    XSSFClientAnchor anchor = pic.getPreferredSize();
                    CTMarker ctMarker = anchor.getFrom();
                    //获取图片对应所在行
                    Row row=xssfSheet.getRow(ctMarker.getRow());
                    //以图片所在行列为键值，以图片路径为value值存取
                    //printImg（）是将图片数据及图片名称传入，保存图片   这里我的图片名称为"_+人名"  返回图片路径
                    pictureMap.put(ctMarker.getRow()+"+"+ctMarker.getCol(), printImg(pic.getPictureData(),"_"+getCellValue(row.getCell(2))));
                }
            }
        }
    }

    /**
     * 保存图片并返回存储地址
     *
     * @param pic
     * @return
     */
    public String printImg(PictureData pic,String name) throws IOException {
        String namePath=name.replace("/","_");
        String ext = pic.suggestFileExtension(); //图片格式
//            生成目录
        File path=new File(ResourceUtils.getURL("classpath:").getPath());
        if(!path.exists()){
            path=new File("");
        }
        //如果上传目录为/static/images/upload/,则可以如下获取
        File upload=new File(path.getAbsolutePath(),"static/photo");
        if(!upload.exists()) {
            upload.mkdirs();
        }
        String filePath=upload.getAbsolutePath()+"\\"+ namePath + "." + ext;
        byte[] data = pic.getData();
        FileOutputStream out = new FileOutputStream(filePath);
        out.write(data);
        out.close();
        return "/photo/"+namePath + "." + ext;
    }
}
