package cn.colins.springcloudsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcloudSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcloudSearchApplication.class, args);
	}

}
