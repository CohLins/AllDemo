package com.example.demo.service;

import com.example.demo.utils.E3Result;
import org.springframework.web.multipart.MultipartFile;

public interface DemoService {

    E3Result getExcel(MultipartFile file) throws Exception;
}
