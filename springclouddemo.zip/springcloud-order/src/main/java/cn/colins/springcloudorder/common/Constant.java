package cn.colins.springcloudorder.common;

public class Constant {
    public static final String[] URL_NAME={"/item/","",""};
}
