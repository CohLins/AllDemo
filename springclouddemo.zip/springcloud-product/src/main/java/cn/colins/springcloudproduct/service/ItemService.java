package cn.colins.springcloudproduct.service;

import cn.colins.springcloudproduct.model.Item;

public interface ItemService {

    Item selectItemById(Long id);
}
