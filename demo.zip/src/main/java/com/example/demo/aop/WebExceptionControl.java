package com.example.demo.aop;

import com.example.demo.exception.APIException;
import com.example.demo.mapper.SysLogInfoMapper;
import com.example.demo.model.APIResult;
import com.example.demo.model.SysLogInfoWithBLOBs;
import com.example.demo.utils.E3Result;
import com.example.demo.utils.GsonUtils;
import com.example.demo.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@RestControllerAdvice
public class WebExceptionControl {

    private SysLogInfoWithBLOBs sysLogInfoWithBLOBs=SysLogInfoWithBLOBs.getSingleton();
    @Autowired
    private SysLogInfoMapper sysLogInfoMapper;
    @ExceptionHandler(APIException.class)
    public E3Result APIExceptionHandler(APIException e) {
        return E3Result.build(400,e.getMessage());
    }

   @ExceptionHandler(ArithmeticException.class)
    public ResultVO ArithmeticExceptionHandler(ArithmeticException e){
        sysLogInfoWithBLOBs.setRequestReturnValue(GsonUtils.toJson(new ResultVO(201,"不好意思数据出错了")));
        sysLogInfoWithBLOBs.setRequestReturnStatus(201);
        sysLogInfoMapper.updateByPrimaryKeySelective(sysLogInfoWithBLOBs);
       return new ResultVO(201,"不好意思数据出错了");
   }

}
