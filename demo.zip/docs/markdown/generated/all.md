# Springboot+swagger  Demo


<a name="overview"></a>
## 概览
一个使用springboot整合swagger的例子


### 版本信息
*版本* : 1.0


### 联系方式
*名字* : Colins  
*邮箱* : xxxxx


### URI scheme
*域名* : localhost:8080  
*基础路径* : /


### 标签

* demo-controller : Demo Controller
* excel-controller : Excel Controller
* 用户接口 : User Controller




<a name="paths"></a>
## 资源

<a name="demo-controller_resource"></a>
### Demo-controller
Demo Controller


<a name="getredisusingget"></a>
#### getRedis
```
GET /redis
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|object|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/redis
```


##### HTTP响应示例

###### 响应 200
```
json :
"object"
```


<a name="testusingpost"></a>
#### test
```
POST /test/{name}
```


##### 参数

|类型|名称|说明|类型|
|---|---|---|---|
|**Path**|**name**  <br>*必填*|name|string|


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**201**|Created|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/test/string
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="testusingget"></a>
#### test
```
GET /test/{name}
```


##### 参数

|类型|名称|说明|类型|
|---|---|---|---|
|**Path**|**name**  <br>*必填*|name|string|


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/test/string
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="testusingput"></a>
#### test
```
PUT /test/{name}
```


##### 参数

|类型|名称|说明|类型|
|---|---|---|---|
|**Path**|**name**  <br>*必填*|name|string|


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**201**|Created|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/test/string
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="testusingdelete"></a>
#### test
```
DELETE /test/{name}
```


##### 参数

|类型|名称|说明|类型|
|---|---|---|---|
|**Path**|**name**  <br>*必填*|name|string|


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/test/string
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="testusingpatch"></a>
#### test
```
PATCH /test/{name}
```


##### 参数

|类型|名称|说明|类型|
|---|---|---|---|
|**Path**|**name**  <br>*必填*|name|string|


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/test/string
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="testusinghead"></a>
#### test
```
HEAD /test/{name}
```


##### 参数

|类型|名称|说明|类型|
|---|---|---|---|
|**Path**|**name**  <br>*必填*|name|string|


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/test/string
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="testusingoptions"></a>
#### test
```
OPTIONS /test/{name}
```


##### 参数

|类型|名称|说明|类型|
|---|---|---|---|
|**Path**|**name**  <br>*必填*|name|string|


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/test/string
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="excel-controller_resource"></a>
### Excel-controller
Excel Controller


<a name="indexusingpost"></a>
#### index
```
POST /
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**201**|Created|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="indexusingget"></a>
#### index
```
GET /
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="indexusingput"></a>
#### index
```
PUT /
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**201**|Created|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="indexusingdelete"></a>
#### index
```
DELETE /
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="indexusingpatch"></a>
#### index
```
PATCH /
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="indexusinghead"></a>
#### index
```
HEAD /
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="indexusingoptions"></a>
#### index
```
OPTIONS /
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|string|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/
```


##### HTTP响应示例

###### 响应 200
```
json :
"string"
```


<a name="uploadusingpost"></a>
#### upload
```
POST /upload/excel
```


##### 参数

|类型|名称|说明|类型|
|---|---|---|---|
|**FormData**|**file**  <br>*可选*|file|file|


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|[E3Result](#e3result)|
|**201**|Created|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 消耗

* `multipart/form-data`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/upload/excel
```


###### 请求 formData
```
json :
"file"
```


##### HTTP响应示例

###### 响应 200
```
json :
{
  "data" : "object",
  "msg" : "string",
  "status" : 0,
  "total" : 0
}
```


<a name="5b0ad68a45d0727406020ff99714ad3d"></a>
### 用户接口
User Controller


<a name="moreusingpost"></a>
#### 查询用户及爱好
```
POST /more
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|< [User](#user) > array|
|**201**|Created|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/more
```


##### HTTP响应示例

###### 响应 200
```
json :
[ {
  "address" : "string",
  "age" : 0,
  "city" : "string",
  "createTime" : "string",
  "hobbys" : [ {
    "createTime" : "string",
    "describe" : "string",
    "hobby" : "string",
    "id" : 0,
    "userId" : 0
  } ],
  "id" : 0,
  "name" : "string",
  "picUrl" : "string",
  "sex" : "string",
  "updateTime" : "string"
} ]
```


<a name="moreusingget"></a>
#### 查询用户及爱好
```
GET /more
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|< [User](#user) > array|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/more
```


##### HTTP响应示例

###### 响应 200
```
json :
[ {
  "address" : "string",
  "age" : 0,
  "city" : "string",
  "createTime" : "string",
  "hobbys" : [ {
    "createTime" : "string",
    "describe" : "string",
    "hobby" : "string",
    "id" : 0,
    "userId" : 0
  } ],
  "id" : 0,
  "name" : "string",
  "picUrl" : "string",
  "sex" : "string",
  "updateTime" : "string"
} ]
```


<a name="moreusingput"></a>
#### 查询用户及爱好
```
PUT /more
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|< [User](#user) > array|
|**201**|Created|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/more
```


##### HTTP响应示例

###### 响应 200
```
json :
[ {
  "address" : "string",
  "age" : 0,
  "city" : "string",
  "createTime" : "string",
  "hobbys" : [ {
    "createTime" : "string",
    "describe" : "string",
    "hobby" : "string",
    "id" : 0,
    "userId" : 0
  } ],
  "id" : 0,
  "name" : "string",
  "picUrl" : "string",
  "sex" : "string",
  "updateTime" : "string"
} ]
```


<a name="moreusingdelete"></a>
#### 查询用户及爱好
```
DELETE /more
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|< [User](#user) > array|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/more
```


##### HTTP响应示例

###### 响应 200
```
json :
[ {
  "address" : "string",
  "age" : 0,
  "city" : "string",
  "createTime" : "string",
  "hobbys" : [ {
    "createTime" : "string",
    "describe" : "string",
    "hobby" : "string",
    "id" : 0,
    "userId" : 0
  } ],
  "id" : 0,
  "name" : "string",
  "picUrl" : "string",
  "sex" : "string",
  "updateTime" : "string"
} ]
```


<a name="moreusingpatch"></a>
#### 查询用户及爱好
```
PATCH /more
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|< [User](#user) > array|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/more
```


##### HTTP响应示例

###### 响应 200
```
json :
[ {
  "address" : "string",
  "age" : 0,
  "city" : "string",
  "createTime" : "string",
  "hobbys" : [ {
    "createTime" : "string",
    "describe" : "string",
    "hobby" : "string",
    "id" : 0,
    "userId" : 0
  } ],
  "id" : 0,
  "name" : "string",
  "picUrl" : "string",
  "sex" : "string",
  "updateTime" : "string"
} ]
```


<a name="moreusinghead"></a>
#### 查询用户及爱好
```
HEAD /more
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|< [User](#user) > array|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/more
```


##### HTTP响应示例

###### 响应 200
```
json :
[ {
  "address" : "string",
  "age" : 0,
  "city" : "string",
  "createTime" : "string",
  "hobbys" : [ {
    "createTime" : "string",
    "describe" : "string",
    "hobby" : "string",
    "id" : 0,
    "userId" : 0
  } ],
  "id" : 0,
  "name" : "string",
  "picUrl" : "string",
  "sex" : "string",
  "updateTime" : "string"
} ]
```


<a name="moreusingoptions"></a>
#### 查询用户及爱好
```
OPTIONS /more
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|< [User](#user) > array|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/more
```


##### HTTP响应示例

###### 响应 200
```
json :
[ {
  "address" : "string",
  "age" : 0,
  "city" : "string",
  "createTime" : "string",
  "hobbys" : [ {
    "createTime" : "string",
    "describe" : "string",
    "hobby" : "string",
    "id" : 0,
    "userId" : 0
  } ],
  "id" : 0,
  "name" : "string",
  "picUrl" : "string",
  "sex" : "string",
  "updateTime" : "string"
} ]
```


<a name="throwtestusingpost"></a>
#### throwTest
```
POST /throw
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|integer (int32)|
|**201**|Created|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/throw
```


##### HTTP响应示例

###### 响应 200
```
json :
0
```


<a name="throwtestusingget"></a>
#### throwTest
```
GET /throw
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|integer (int32)|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/throw
```


##### HTTP响应示例

###### 响应 200
```
json :
0
```


<a name="throwtestusingput"></a>
#### throwTest
```
PUT /throw
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|integer (int32)|
|**201**|Created|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|
|**404**|Not Found|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/throw
```


##### HTTP响应示例

###### 响应 200
```
json :
0
```


<a name="throwtestusingdelete"></a>
#### throwTest
```
DELETE /throw
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|integer (int32)|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/throw
```


##### HTTP响应示例

###### 响应 200
```
json :
0
```


<a name="throwtestusingpatch"></a>
#### throwTest
```
PATCH /throw
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|integer (int32)|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/throw
```


##### HTTP响应示例

###### 响应 200
```
json :
0
```


<a name="throwtestusinghead"></a>
#### throwTest
```
HEAD /throw
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|integer (int32)|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/throw
```


##### HTTP响应示例

###### 响应 200
```
json :
0
```


<a name="throwtestusingoptions"></a>
#### throwTest
```
OPTIONS /throw
```


##### 响应

|HTTP代码|说明|类型|
|---|---|---|
|**200**|OK|integer (int32)|
|**204**|No Content|无内容|
|**401**|Unauthorized|无内容|
|**403**|Forbidden|无内容|


##### 消耗

* `application/json`


##### 生成

* `*/*`


##### HTTP请求示例

###### 请求 path
```
/throw
```


##### HTTP响应示例

###### 响应 200
```
json :
0
```




<a name="definitions"></a>
## 定义

<a name="e3result"></a>
### E3Result

|名称|说明|类型|
|---|---|---|
|**data**  <br>*可选*|**样例** : `"object"`|object|
|**msg**  <br>*可选*|**样例** : `"string"`|string|
|**status**  <br>*可选*|**样例** : `0`|integer (int32)|
|**total**  <br>*可选*|**样例** : `0`|integer (int32)|


<a name="user"></a>
### User

|名称|说明|类型|
|---|---|---|
|**address**  <br>*可选*|用户地址  <br>**样例** : `"string"`|string|
|**age**  <br>*可选*|用户年龄  <br>**样例** : `0`|integer (int32)|
|**city**  <br>*可选*|用户城市  <br>**样例** : `"string"`|string|
|**createTime**  <br>*可选*|用户创建时间  <br>**样例** : `"string"`|string (date-time)|
|**hobbys**  <br>*可选*|用户爱好  <br>**样例** : `[ "[userhobby](#userhobby)" ]`|< [UserHobby](#userhobby) > array|
|**id**  <br>*可选*|用户id  <br>**样例** : `0`|integer (int32)|
|**name**  <br>*可选*|用户名字  <br>**样例** : `"string"`|string|
|**picUrl**  <br>*可选*|用户图片路径  <br>**样例** : `"string"`|string|
|**sex**  <br>*可选*|用户性别  <br>**样例** : `"string"`|string|
|**updateTime**  <br>*可选*|用户更新时间  <br>**样例** : `"string"`|string (date-time)|


<a name="userhobby"></a>
### UserHobby

|名称|说明|类型|
|---|---|---|
|**createTime**  <br>*可选*|创建时间  <br>**样例** : `"string"`|string (date-time)|
|**describe**  <br>*可选*|爱好描述  <br>**样例** : `"string"`|string|
|**hobby**  <br>*可选*|用户爱好  <br>**样例** : `"string"`|string|
|**id**  <br>*可选*|序号ID  <br>**样例** : `0`|integer (int32)|
|**userId**  <br>*可选*|用户ID  <br>**样例** : `0`|integer (int32)|





