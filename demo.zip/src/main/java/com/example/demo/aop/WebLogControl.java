package com.example.demo.aop;

import com.example.demo.Constant;
import com.example.demo.annotation.LogAnnotation;
import com.example.demo.mapper.SysLogErrorMapper;
import com.example.demo.mapper.SysLogInfoMapper;
import com.example.demo.model.SysLogError;
import com.example.demo.model.SysLogInfo;
import com.example.demo.model.SysLogInfoWithBLOBs;
import com.example.demo.utils.GsonUtils;
import com.example.demo.vo.ResultVO;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.util.*;

@Aspect
@Component
public class WebLogControl {
    private static final Logger logger = LoggerFactory.getLogger(WebLogControl.class);
    //请求时间
    ThreadLocal<Long> startTime = new ThreadLocal<>();

    //日志类
    private static SysLogInfoWithBLOBs sysLogInfo=SysLogInfoWithBLOBs.getSingleton();
    @Autowired
    private SysLogInfoMapper sysLogInfoMapper;
    @Autowired
    private SysLogErrorMapper sysLogErrorMapper;
//    private static Logger logger=Logger.getLogger(WebLogControl.class);

    @Pointcut("execution(public * com.example.demo.controller.*.*(..))")
    public void webLog() {

    }



    @Before("webLog()")
    public void doBefore(JoinPoint joinPoint) throws Throwable {
        //初始化可能会冲突的值，因为是单例模式
        initData();
        startTime.set(System.currentTimeMillis());

        // 接收到请求，记录请求内容
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        //1.获取请求参数值
//        Map<String, String[]> parameterMap = request.getParameterMap();
//        GsonUtils.toJson(joinPoint.getArgs());

        MethodSignature signature = (MethodSignature)joinPoint.getSignature();
//        2.获取请求的方法所在类名
        String beanName = joinPoint.getSignature().getDeclaringTypeName(); //方法所在的类名
        //3.获取请求的方法
        Method method = signature.getMethod();
        //4.获取注解参数值
        LogAnnotation annotation = signature.getMethod().getAnnotation(LogAnnotation.class);
        // 打印日志
        logger.info("  TypeName  : " + beanName);
        logger.info(" MethodName : " + method.getName());
        logger.info("  U  R  L   : " + request.getServletPath());
        logger.info("HTTP_METHOD : " + request.getMethod());
        logger.info("    I P     : " + request.getRemoteAddr());
        logger.info("   PARAM    : " + GsonUtils.toJson(joinPoint.getArgs()));
        logger.info(" SPEND TIME : " + (System.currentTimeMillis() - startTime.get())+"ms");

        //下面进行日志填充
        sysLogInfo.setLogType(Constant.LOG_INFO);
        sysLogInfo.setHttpType(request.getMethod());
        sysLogInfo.setRequestBeanName(beanName);
        sysLogInfo.setRequestTime(Integer.valueOf(String.valueOf((System.currentTimeMillis() - startTime.get()))));
        sysLogInfo.setRequestUrl(request.getServletPath());
        sysLogInfo.setRequestIp(request.getRemoteAddr());
        sysLogInfo.setRequestMethod(method.getName());
        sysLogInfo.setUrlRemark(annotation==null ? null:annotation.requestRemark());
        sysLogInfo.setRequestParam(GsonUtils.toJson(joinPoint.getArgs()));
        sysLogInfo.setCreateTime(new Date());
    }

    @AfterReturning(returning = "ret", pointcut = "webLog()")
    public void doAfterReturning(Object ret) throws Throwable {
        if (ret instanceof ResultVO) {
            ResultVO resultVO = (ResultVO)ret;
            sysLogInfo.setRequestReturnStatus(resultVO.getCode());
        }



        // 处理完请求，返回内容
        logger.info("RESPONSE : " + GsonUtils.toJson(ret));

        sysLogInfo.setRequestReturnValue(GsonUtils.toJson(ret));
        sysLogInfoMapper.insertSelective(sysLogInfo);
    }

    @AfterThrowing( pointcut = "webLog()",throwing = "e")
    public void logThrowing(JoinPoint joinPoint,Throwable e){
        logger.error("**************开始抛出异常***************");
        logger.error("请求类方法:"+joinPoint.getSignature().getName());
        logger.error("异常内容:  "+getTrace(e));
        logger.error("***************抛出异常结束***************");

        //下面填充
        sysLogInfo.setLogType(Constant.LOG_ERRO);
        //插入主表后获取主表id  后插入error附表
        sysLogInfoMapper.insertSelective(sysLogInfo);

        SysLogError sysLogError = new SysLogError();
        sysLogError.setCreateTime(new Date());
        sysLogError.setLogId(sysLogInfo.getId()==null ? -1:sysLogInfo.getId());
        sysLogError.setErrorContent(getTrace(e));
        sysLogError.setErrorInfo(e.getMessage());
        sysLogErrorMapper.insertSelective(sysLogError);
    }
    /**
     * 总结缺少几个参数：1.error详细内容  2.请求的具体方法名称   3.请求的方法所在具体controller  4.返回参数的解析  5.请求时间
     */
    //异常信息转化
    public static String getTrace(Throwable t) {
        StringWriter stringWriter= new StringWriter();
        PrintWriter writer= new PrintWriter(stringWriter);
        t.printStackTrace(writer);
        StringBuffer buffer= stringWriter.getBuffer();
        return buffer.toString();
    }

    public static void initData(){
        sysLogInfo.setId(null);
        sysLogInfo.setUrlRemark(null);
        sysLogInfo.setHttpType(null);
        sysLogInfo.setRequestUrl(null);
        sysLogInfo.setRequestParam(null);
        sysLogInfo.setRequestReturnValue(null);
        sysLogInfo.setRequestReturnStatus(null);
    }

}