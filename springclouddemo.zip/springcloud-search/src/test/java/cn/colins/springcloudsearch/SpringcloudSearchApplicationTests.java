package cn.colins.springcloudsearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcloudSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
