package com.example.demo.model;

public class SysLogInfoWithBLOBs extends SysLogInfo {
    //使用volatile保证线程的可见性,
    private static volatile SysLogInfoWithBLOBs SysLogInfoWithBLOBs = null;
    //这里写个私有的构造函数是防止在外部可以直接new这个对象
    private SysLogInfoWithBLOBs() {

    }
    public static SysLogInfoWithBLOBs getSingleton() {
        if (SysLogInfoWithBLOBs == null) {//添加判断减少排队，提高效率
            //加锁保证线程安全
            synchronized (SysLogInfoWithBLOBs.class) {
                if (SysLogInfoWithBLOBs == null) {
                    SysLogInfoWithBLOBs = new SysLogInfoWithBLOBs();
                }
            }
        }
        return SysLogInfoWithBLOBs;
    }
    private String requestParam;

    private String requestReturnValue;

    public String getRequestParam() {
        return requestParam;
    }

    public void setRequestParam(String requestParam) {
        this.requestParam = requestParam == null ? null : requestParam.trim();
    }

    public String getRequestReturnValue() {
        return requestReturnValue;
    }

    public void setRequestReturnValue(String requestReturnValue) {
        this.requestReturnValue = requestReturnValue == null ? null : requestReturnValue.trim();
    }
}