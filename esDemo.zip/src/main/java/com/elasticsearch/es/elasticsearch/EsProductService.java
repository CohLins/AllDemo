package com.elasticsearch.es.elasticsearch;

import com.elasticsearch.es.model.TbProductWithBLOBs;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import java.util.List;

public interface EsProductService extends ElasticsearchRepository<TbProductWithBLOBs,Integer> {

    //根据技术参数、详细信息、功能特点查询数据
    List<TbProductWithBLOBs> findByTraitAndTechnicalDataAndDetailInfo(String trait,String technicalData,String detail);

    List<TbProductWithBLOBs> findByTraitAndName(String trait,String name);

}
