package com.example.demo.model;

import java.util.Date;

/**
 * 标签定位数据表
 * 对应数据库表为：label_location_info
 * 
 * @author Colins
 * @date 2021/03/20
 */
public class LabelLocationInfo {
    /**
     * 对应表字段：id
     */
    private Integer id;

    /**
     * 人员姓名
     * 对应表字段：user_name
     */
    private String userName;

    /**
     * 人员头像Url
     * 对应表字段：user_pic_url
     */
    private String userPicUrl;

    /**
     * 人员类别url
     * 对应表字段：user_type_url
     */
    private String userTypeUrl;

    /**
     * mac地址
     * 对应表字段：mac_address
     */
    private String macAddress;

    /**
     * x坐标
     * 对应表字段：tag_x
     */
    private Double tagX;

    /**
     * y坐标
     * 对应表字段：tag_y
     */
    private Double tagY;

    /**
     * 参与定位基站数量
     * 对应表字段：station_num
     */
    private Integer stationNum;

    /**
     * 参与定位基站数组
     * 对应表字段：station_array
     */
    private String stationArray;

    /**
     * 主基站id
     * 对应表字段：station_main_id
     */
    private Integer stationMainId;

    /**
     * 地图Id
     * 对应表字段：map_id
     */
    private Integer mapId;

    /**
     * 地图名称
     * 对应表字段：map_name
     */
    private String mapName;

    /**
     * 地图路径
     * 对应表字段：map_url
     */
    private String mapUrl;

    /**
     * 对应表字段：create_time
     */
    private Date createTime;

    /**
     * 宽度比列
     * 对应表字段：width_scale
     */
    private Double widthScale;

    /**
     * 长度比列
     * 对应表字段：length_scale
     */
    private Double lengthScale;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public String getUserPicUrl() {
        return userPicUrl;
    }

    public void setUserPicUrl(String userPicUrl) {
        this.userPicUrl = userPicUrl == null ? null : userPicUrl.trim();
    }

    public String getUserTypeUrl() {
        return userTypeUrl;
    }

    public void setUserTypeUrl(String userTypeUrl) {
        this.userTypeUrl = userTypeUrl == null ? null : userTypeUrl.trim();
    }

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress == null ? null : macAddress.trim();
    }

    public Double getTagX() {
        return tagX;
    }

    public void setTagX(Double tagX) {
        this.tagX = tagX;
    }

    public Double getTagY() {
        return tagY;
    }

    public void setTagY(Double tagY) {
        this.tagY = tagY;
    }

    public Integer getStationNum() {
        return stationNum;
    }

    public void setStationNum(Integer stationNum) {
        this.stationNum = stationNum;
    }

    public String getStationArray() {
        return stationArray;
    }

    public void setStationArray(String stationArray) {
        this.stationArray = stationArray == null ? null : stationArray.trim();
    }

    public Integer getStationMainId() {
        return stationMainId;
    }

    public void setStationMainId(Integer stationMainId) {
        this.stationMainId = stationMainId;
    }

    public Integer getMapId() {
        return mapId;
    }

    public void setMapId(Integer mapId) {
        this.mapId = mapId;
    }

    public String getMapName() {
        return mapName;
    }

    public void setMapName(String mapName) {
        this.mapName = mapName == null ? null : mapName.trim();
    }

    public String getMapUrl() {
        return mapUrl;
    }

    public void setMapUrl(String mapUrl) {
        this.mapUrl = mapUrl == null ? null : mapUrl.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Double getWidthScale() {
        return widthScale;
    }

    public void setWidthScale(Double widthScale) {
        this.widthScale = widthScale;
    }

    public Double getLengthScale() {
        return lengthScale;
    }

    public void setLengthScale(Double lengthScale) {
        this.lengthScale = lengthScale;
    }
}