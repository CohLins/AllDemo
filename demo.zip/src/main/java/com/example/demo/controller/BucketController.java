package com.example.demo.controller;

import com.example.demo.annotation.BucketAnnotation;
import com.example.demo.utils.BucketUtil;
import com.example.demo.utils.E3Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.atomic.AtomicInteger;

@RestController
public class BucketController {

    @BucketAnnotation
    @RequestMapping(value = "/bucket")
    public  E3Result bucket(){
        return E3Result.ok("访问成功");
    }

    @RequestMapping(value = "/getI")
    public E3Result getI(){
        return E3Result.ok(BucketUtil.buckets.get("bucket").getSize());
    }
}
