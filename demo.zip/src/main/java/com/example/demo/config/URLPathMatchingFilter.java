//package com.example.demo.config;
//
//import com.example.demo.database.UserBean;
//import com.example.demo.database.UserService;
//import com.example.demo.exception.APIException;
//import org.apache.shiro.web.filter.PathMatchingFilter;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import javax.servlet.ServletRequest;
//import javax.servlet.ServletResponse;
//import javax.servlet.http.HttpServletRequest;
//
//public class URLPathMatchingFilter extends PathMatchingFilter {
//    @Autowired
//    UserService loginService;
//
//    @Override
//    protected boolean onPreHandle(ServletRequest request, ServletResponse response, Object mappedValue) throws Exception {
//
//        if (loginService==null){
//            loginService= SpringContextUtil.getContext().getBean(LoginService.class);
//        }
//        请求的url
//        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
//        String authorization = httpServletRequest.getHeader("Authorization");
//        String requestURL = getPathWithinApplication(request);
//        System.out.println("请求的url :"+requestURL);
////        Subject subject = SecurityUtils.getSubject();
//        if (authorization==null){
//            // 如果没有登录, 直接返回true 进入登录流程
//            throw  new APIException("当前用户未登录");
//        }
//
//        UserBean user =
//        String[] split = user.getPermission().split(",");
//        boolean hasPermission = false;
//        for (int i =0;i<split.length;i++) {
//            if (split[i].equals(requestURL)){
//                hasPermission = true;
//                break;
//            }
//        }
//        if (hasPermission){
//            return true;
//        }else {
//            throw  new APIException("当前用户没有访问路径" + requestURL + "的权限");
//        }
//
//    }
//}
