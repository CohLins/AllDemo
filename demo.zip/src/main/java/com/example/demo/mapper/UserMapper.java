package com.example.demo.mapper;

import com.example.demo.model.Product;
import com.example.demo.model.User;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Param;

import javax.jws.soap.SOAPBinding;
import java.util.List;

public interface UserMapper {
    //根据ID查找数据
    User findById(Integer id);
    //根据ID更新数据
    int updateById(@Param("param")User user);
    //根据ID插入数据
    void insertData(User user);
    int deleteById(Integer id);

    List<User> queryMoreData();


    int updateByIdProduct(@Param("param")Product product);
    Product findByIdProduct(Integer id);

}