package com.elasticsearch.es.model;

import lombok.Data;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

@Data
public class TbProductWithBLOBs extends TbProduct {
    @Field(type = FieldType.Text)
    private String specs;
    @Field(type = FieldType.Text)
    private String parts;
    @Field(type = FieldType.Text,analyzer = "ik_smart",searchAnalyzer = "ik_max_word")
    private String technicalData;
    @Field(type = FieldType.Text,analyzer = "ik_smart",searchAnalyzer = "ik_max_word")
    private String detailInfo;
    @Field(type = FieldType.Text)
    private String synopsis;
    @Field(type = FieldType.Text,analyzer = "ik_smart",searchAnalyzer = "ik_max_word")
    private String trait;
    @Field(type = FieldType.Text)
    private String note;
}