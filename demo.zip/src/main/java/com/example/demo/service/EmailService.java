package com.example.demo.service;

/**
 * @program: demo
 * @description: 邮件相关方法接口
 * @author: colins
 * @create: 2020-11-18 15:53
 **/
public interface EmailService {
    /**
     * 发送文本邮件
     * @param to 收件人
     * @param subject 主题
     * @param content 内容
     */
    void sendSimpleMail(String to, String subject, String content);

    /**
     * @Author colins
     * @Description 发送HTML邮件
     * @Date 2020/11/18 16:06
     * @Param [to, subject, content]
     * @return void
     **/
    void sendHtmlMail(String to, String subject, String content);

    /**
     * 发送带附件的邮件
     * @param to 收件人
     * @param subject 主题
     * @param content 内容
     * @param filePath 附件
     */
    public void sendAttachmentsMail(String to, String subject, String content, String filePath);
}