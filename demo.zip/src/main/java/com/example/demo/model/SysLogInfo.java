package com.example.demo.model;

import java.util.Date;

public class SysLogInfo {

    private Integer id;

    private Integer userId;

    private String userName;

    private Integer logType;

    private String httpType;

    private String requestUrl;

    private String urlRemark;

    private String requestIp;

    private String requestMethod;

    private String requestBeanName;

    private Integer requestReturnStatus;

    private Integer requestTime;

    private Date createTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public Integer getLogType() {
        return logType;
    }

    public void setLogType(Integer logType) {
        this.logType = logType;
    }

    public String getHttpType() {
        return httpType;
    }

    public void setHttpType(String httpType) {
        this.httpType = httpType == null ? null : httpType.trim();
    }

    public String getRequestUrl() {
        return requestUrl;
    }

    public void setRequestUrl(String requestUrl) {
        this.requestUrl = requestUrl == null ? null : requestUrl.trim();
    }

    public String getUrlRemark() {
        return urlRemark;
    }

    public void setUrlRemark(String urlRemark) {
        this.urlRemark = urlRemark == null ? null : urlRemark.trim();
    }

    public String getRequestIp() {
        return requestIp;
    }

    public void setRequestIp(String requestIp) {
        this.requestIp = requestIp == null ? null : requestIp.trim();
    }

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod == null ? null : requestMethod.trim();
    }

    public String getRequestBeanName() {
        return requestBeanName;
    }

    public void setRequestBeanName(String requestBeanName) {
        this.requestBeanName = requestBeanName == null ? null : requestBeanName.trim();
    }

    public Integer getRequestReturnStatus() {
        return requestReturnStatus;
    }

    public void setRequestReturnStatus(Integer requestReturnStatus) {
        this.requestReturnStatus = requestReturnStatus;
    }

    public Integer getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Integer requestTime) {
        this.requestTime = requestTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}