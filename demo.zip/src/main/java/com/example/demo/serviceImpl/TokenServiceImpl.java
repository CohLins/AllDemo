package com.example.demo.serviceImpl;

import com.example.demo.exception.APIException;
import com.example.demo.service.TokenService;
import com.example.demo.utils.E3Result;
import com.example.demo.utils.RandomUtils;
import com.example.demo.utils.RedisUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.StrBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

@Service
public class TokenServiceImpl implements TokenService {

    private static final String TOKEN_NAME = "token";

    @Autowired
    private RedisUtils redisUtils;

    @Override
    public E3Result createToken() {
        String str = RandomUtils.randomNumberString(24);
        StrBuilder token = new StrBuilder();
        token.append(str);

        redisUtils.set(token.toString(), token.toString(),1000*60*10);

        return E3Result.ok(token.toString());
    }

    @Override
    public E3Result checkToken(HttpServletRequest request) {
        String token = request.getHeader(TOKEN_NAME);
        if (StringUtils.isBlank(token)) {// header中不存在token
            token = request.getParameter(TOKEN_NAME);
            System.out.println(token);
            if (StringUtils.isBlank(token)) {// parameter中也不存在token
                throw  new APIException("param token不存在");
            }
        }

        if (redisUtils.get(token)==null) {
            throw  new APIException("Redis token不存在");
        }

        redisUtils.del(token);
        if (redisUtils.get(token)!=null) {
            throw  new APIException("del token fail");
        }
        return E3Result.ok();
    }

}