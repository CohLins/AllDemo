package com.elasticsearch.es.controller;

import com.elasticsearch.es.annotation.LogAnnotation;
import com.elasticsearch.es.elasticsearch.EsProductService;
import com.elasticsearch.es.elasticsearch.EsUserService;
import com.elasticsearch.es.mapper.TbProductMapper;
import com.elasticsearch.es.model.TbProductExample;
import com.elasticsearch.es.model.TbProductWithBLOBs;
import com.elasticsearch.es.model.User;
import com.elasticsearch.es.vo.ResultVO;
import org.apache.lucene.util.QueryBuilder;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.QueryStringQueryBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.query.HighlightQueryBuilder;
import org.springframework.data.elasticsearch.core.query.NativeSearchQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@RequestMapping("es")
@RestController
public class EsDemoController {
    @Autowired
    private EsProductService esProductService;
    @Autowired
    private TbProductMapper tbProductMapper;
    @Autowired
    private ElasticsearchRestTemplate elasticsearchTemplate;
    @Autowired
    private EsUserService esUserService;

    @LogAnnotation(requestRemark = "存数据")
    @GetMapping("saveUser")
    public ResultVO saveUser(){
        elasticsearchTemplate.putMapping(User.class);
        User user=new User();
        user.setAge(20);
        user.setId(1);
        user.setInfo("我家有四口人，家住大东北，一口大碴子话");
        user.setName("中华人民共和国国歌");
        User save = esUserService.save(user);
        return new ResultVO(save);
    }
    @LogAnnotation(requestRemark = "存数据")
    @GetMapping("getUser")
    public ResultVO getUser(){
        return new ResultVO(esUserService.findAll());
    }


    @LogAnnotation(requestRemark = "存数据")
    @GetMapping("saveData")
    public ResultVO saveData(){
        TbProductExample example = new TbProductExample();
        List<TbProductWithBLOBs> tbProductWithBLOBs = tbProductMapper.selectByExampleWithBLOBs(example);
        //直接把查询到的数据存进去，并把数据返回
        Iterable<TbProductWithBLOBs> tbProductWithBLOBs1 = esProductService.saveAll(tbProductWithBLOBs);
        return new ResultVO(tbProductWithBLOBs1);
    }

    @LogAnnotation(requestRemark = "根据id取数据")
    @GetMapping("getDataById")
    public ResultVO getDataById(Integer id){
        Optional<TbProductWithBLOBs> byId = esProductService.findById(id);
        return new ResultVO(byId);

    }

    @LogAnnotation(requestRemark = "取所有数据")
    @GetMapping("getDataAll")
    public ResultVO getDataAll(){
        Iterable<TbProductWithBLOBs> all = esProductService.findAll();
        return new ResultVO(all);
    }

    @LogAnnotation(requestRemark = "取所有数据并分页")
    @GetMapping("getDataAllByPage")
    public ResultVO getDataAllByPage(){
        //Pageable对象的手动实现分页 排序
        Pageable page = PageRequest.of(0,10, Sort.Direction.ASC,"id");
        Page<TbProductWithBLOBs> all = esProductService.findAll(page);
        return new ResultVO(all);
    }

    @LogAnnotation(requestRemark = "根据值查询三个字段内容 交集")
    @GetMapping("seleteByValue1")
    public ResultVO seleteByValue(String value){
        //这里的方法是自定义的  根据一个值查询三个字段  多个字段取交集
        List<TbProductWithBLOBs> byTraitAndTechnicalDataAndDetailInfo = esProductService.findByTraitAndName(value,value);
        return new ResultVO(byTraitAndTechnicalDataAndDetailInfo);
    }

    @LogAnnotation(requestRemark = "根据值查询三个字段内容 并集")
    @GetMapping("seleteByValue2")
    public ResultVO seleteByValue2(String value){
        //根据一个值查询多个字段  取并集
        NativeSearchQuery searchQuery = new NativeSearchQueryBuilder()
                .withQuery(QueryBuilders.matchQuery("trait", value))
                .withQuery(QueryBuilders.matchQuery("technicalData", value))
                .withQuery(QueryBuilders.matchQuery("name", value))
                .build();
        SearchHits<TbProductWithBLOBs> search = elasticsearchTemplate.search(searchQuery, TbProductWithBLOBs.class);
        return new ResultVO(search.getSearchHits());
    }

    @LogAnnotation(requestRemark = "查询高亮显示")
    @GetMapping("seleteByHightLight")
    public ResultVO seleteByHightLight(String value){
        //根据一个值查询多个字段  并高亮显示
        //需要查询的字段
        BoolQueryBuilder boolQueryBuilder= QueryBuilders.boolQuery()
                .should(QueryBuilders.matchQuery("trait",value))
                .should(QueryBuilders.matchQuery("technicalData",value))
                .should(QueryBuilders.matchQuery("name",value));

        NativeSearchQuery searchQuery = new NativeSearchQueryBuilder()
                .withQuery(boolQueryBuilder)
                .withHighlightFields(new HighlightBuilder.Field("trait")
                        ,new HighlightBuilder.Field("technicalData")
                        ,new HighlightBuilder.Field("name"))
                .withHighlightBuilder(new HighlightBuilder().preTags("<span style='color:red'>").postTags("</span>"))
                .build();
        SearchHits<TbProductWithBLOBs> search = elasticsearchTemplate.search(searchQuery, TbProductWithBLOBs.class);
        //得到查询返回的内容
        List<SearchHit<TbProductWithBLOBs>> searchHits = search.getSearchHits();
        //设置一个最后需要返回的实体类集合
        List<TbProductWithBLOBs> tbProductWithBLOBs = new ArrayList<>();
        for(SearchHit<TbProductWithBLOBs> searchHit:searchHits){
            //高亮的内容
            Map<String, List<String>> highlightFields = searchHit.getHighlightFields();
            //将高亮的内容填充到content中
            searchHit.getContent().setTechnicalData(highlightFields.get("technicalData")==null ? null:highlightFields.get("technicalData").get(0));
            searchHit.getContent().setName(highlightFields.get("name")==null ? null:highlightFields.get("name").get(0));
            searchHit.getContent().setTrait(highlightFields.get("trait")==null ? null:highlightFields.get("trait").get(0));
            //放到实体类中
            tbProductWithBLOBs.add(searchHit.getContent());
        }
        return new ResultVO(tbProductWithBLOBs);
    }

//    @LogAnnotation(requestRemark = "查询高亮显示")
//    @GetMapping("seleteByHightLightUser")
//    public ResultVO seleteByHightLightUser(String value){
//        //根据一个值查询多个字段  并高亮显示
//        //需要查询的字段
//        BoolQueryBuilder boolQueryBuilder= QueryBuilders.boolQuery()
//                .should(QueryBuilders.matchQuery("info",value))
//                .should(QueryBuilders.matchQuery("name",value));
//
//        NativeSearchQuery searchQuery = new NativeSearchQueryBuilder()
//                .withQuery(boolQueryBuilder)
//                .withHighlightFields(
//                        new HighlightBuilder.Field("info")
//                        ,new HighlightBuilder.Field("name"))
//                .withHighlightBuilder(new HighlightBuilder().preTags("<span style='color:red'>").postTags("</span>"))
//                .build();
//        SearchHits<User> search = elasticsearchTemplate.search(searchQuery, User.class);
//        //得到查询返回的内容
//        List<SearchHit<User>> searchHits = search.getSearchHits();
//        //设置一个最后需要返回的实体类集合
//        List<User> tbProductWithBLOBs = new ArrayList<>();
//        for(SearchHit<User> searchHit:searchHits){
//            //高亮的内容
//            Map<String, List<String>> highlightFields = searchHit.getHighlightFields();
//            //将高亮的内容填充到content中
//            searchHit.getContent().setName(highlightFields.get("name")==null ? searchHit.getContent().getName():highlightFields.get("name").get(0));
//            searchHit.getContent().setInfo(highlightFields.get("info")==null ? searchHit.getContent().getInfo():highlightFields.get("info").get(0));
//            //放到实体类中
//            tbProductWithBLOBs.add(searchHit.getContent());
//        }
//        return new ResultVO(tbProductWithBLOBs);
//    }



}
