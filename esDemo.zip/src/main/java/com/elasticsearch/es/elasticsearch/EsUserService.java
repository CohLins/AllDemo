package com.elasticsearch.es.elasticsearch;

import com.elasticsearch.es.model.TbProductWithBLOBs;
import com.elasticsearch.es.model.User;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import java.util.List;
import java.util.Optional;

public interface EsUserService extends ElasticsearchRepository<User,Integer> {
    //根据name查询
    List<User> findByName(String name);

    //根据name和info查询
    List<User> findByNameAndInfo(String name,String info);
}
