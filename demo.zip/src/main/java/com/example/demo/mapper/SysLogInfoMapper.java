package com.example.demo.mapper;

import com.example.demo.model.SysLogInfo;
import com.example.demo.model.SysLogInfoExample;
import com.example.demo.model.SysLogInfoWithBLOBs;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SysLogInfoMapper {
    int countByExample(SysLogInfoExample example);

    int deleteByExample(SysLogInfoExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysLogInfoWithBLOBs record);

    int insertSelective(SysLogInfoWithBLOBs record);

    List<SysLogInfoWithBLOBs> selectByExampleWithBLOBs(SysLogInfoExample example);

    List<SysLogInfo> selectByExample(SysLogInfoExample example);

    SysLogInfoWithBLOBs selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysLogInfoWithBLOBs record, @Param("example") SysLogInfoExample example);

    int updateByExampleWithBLOBs(@Param("record") SysLogInfoWithBLOBs record, @Param("example") SysLogInfoExample example);

    int updateByExample(@Param("record") SysLogInfo record, @Param("example") SysLogInfoExample example);

    int updateByPrimaryKeySelective(SysLogInfoWithBLOBs record);

    int updateByPrimaryKeyWithBLOBs(SysLogInfoWithBLOBs record);

    int updateByPrimaryKey(SysLogInfo record);
}