package com.example.demo;

public enum  LogRequestTypeEnum {
    ADD("添加",1),

    DEL("删除",2),

    UPDATE("修改",3),

    SELECT("查询",4);
    private String operateDesc;
    private int operateCode;


    LogRequestTypeEnum(String operateDesc,int operateCode){
        this.operateDesc=operateDesc;
        this.operateCode=operateCode;
    }

    public static String getMessage(int operateCode){
        //通过enum.values()获取所有的枚举值
        for(LogRequestTypeEnum logOperateTypeEnum : LogRequestTypeEnum.values()){
            //通过enum.get获取字段值
            if(logOperateTypeEnum.getOperateCode() == operateCode){
                return logOperateTypeEnum.operateDesc;
            }
        }
        return null;
    }

    public String getOperateDesc() {
        return operateDesc;
    }

    public int getOperateCode() {
        return operateCode;
    }

    public void setOperateDesc(String operateDesc) {
        this.operateDesc = operateDesc;
    }

    public void setOperateCode(int operateCode) {
        this.operateCode = operateCode;
    }
}
