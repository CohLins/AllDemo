package com.elasticsearch.es.vo;


import com.elasticsearch.es.common.APIResult;
import lombok.Getter;
import lombok.ToString;

/**
 * @author RudeCrab
 * @description 自定义统一响应体
 */
@Getter
@ToString
public class ResultVO {
    private int code;
    private String msg;
    private int total;
    private Object data;

    public ResultVO(){
        this(APIResult.RESULT_SUCCESS,null);
    }

    public ResultVO(Object data) {
        this(APIResult.RESULT_SUCCESS, data);
    }
    public ResultVO(int resultCode, String msg) {
        this.code = resultCode;
        this.msg = msg;
    }

    public ResultVO(APIResult resultCode, Object data) {
        this.code = resultCode.getCode();
        this.msg = resultCode.getMsg();
        this.data = data;
    }
    public ResultVO(APIResult resultCode, Integer total, Object data) {
        this.code = resultCode.getCode();
        this.msg = resultCode.getMsg();
        this.total=total;
        this.data = data;
    }

}
