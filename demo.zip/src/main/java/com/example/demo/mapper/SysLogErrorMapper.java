package com.example.demo.mapper;

import com.example.demo.model.SysLogError;
import com.example.demo.model.SysLogErrorExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SysLogErrorMapper {
    int countByExample(SysLogErrorExample example);

    int deleteByExample(SysLogErrorExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysLogError record);

    int insertSelective(SysLogError record);

    List<SysLogError> selectByExampleWithBLOBs(SysLogErrorExample example);

    List<SysLogError> selectByExample(SysLogErrorExample example);

    SysLogError selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysLogError record, @Param("example") SysLogErrorExample example);

    int updateByExampleWithBLOBs(@Param("record") SysLogError record, @Param("example") SysLogErrorExample example);

    int updateByExample(@Param("record") SysLogError record, @Param("example") SysLogErrorExample example);

    int updateByPrimaryKeySelective(SysLogError record);

    int updateByPrimaryKeyWithBLOBs(SysLogError record);

    int updateByPrimaryKey(SysLogError record);
}