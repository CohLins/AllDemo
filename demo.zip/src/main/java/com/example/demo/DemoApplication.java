package com.example.demo;

import com.example.demo.annotation.BucketAnnotation;
import com.example.demo.interceptor.ApiIdempotentInterceptor;
import com.example.demo.interceptor.BucketInterceptor;
import com.example.demo.utils.BucketUtil;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@MapperScan("com.example.demo.mapper")
@EnableScheduling
@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
		// 为了方便测试这里定义1容量  1增长速率
		BucketUtil bucketUtil = new BucketUtil(1,1);
		// 生成名为：bucket的令牌桶
		BucketUtil.buckets.put("bucket",bucketUtil);
	}
	@Scheduled(fixedRate = 1000)// 定时1s
	public void timer() {
		if (BucketUtil.buckets.containsKey("bucket")){
			//名为：bucket的令牌桶 开始不断生成令牌
			BucketUtil.buckets.get("bucket").incrTokens();
		}
	}
}
