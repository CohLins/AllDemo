package com.example.demo.service;

import com.example.demo.utils.E3Result;
import org.springframework.web.servlet.function.ServerResponse;

import javax.servlet.http.HttpServletRequest;

public interface TokenService {
    public E3Result createToken();

    public E3Result checkToken(HttpServletRequest request);
}
