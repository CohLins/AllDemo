package com.example.demo.controller;

import com.example.demo.LogRequestTypeEnum;
import com.example.demo.annotation.LogAnnotation;
import com.example.demo.model.User;
import com.example.demo.model.UserHobby;
import com.example.demo.vo.ResultVO;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping(value = "/log")
@RestController
public class LogTestController {

    @LogAnnotation(requestRemark = "测试")
    @RequestMapping(value = "test")
    public ResultVO test1(String id,String name){
        return new ResultVO();
    }

    @RequestMapping(value = "test2")
    public ResultVO test2(String id,String name){
        int a=5;
        return new ResultVO(5/0);
    }


    @PostMapping(value = "test3")
    public ResultVO test3(@RequestBody UserHobby user){
        return new ResultVO(user);
    }


}
