package com.example.demo.model;

import lombok.Getter;

@Getter
public enum APIResult {
    RESULT_SUCCESS(200,"SUCCESS"),
    RESULT_FAIL(400,"接口错误"),
    PARAM_NULL_FAIL(1001,"TOKEN 校验失败"),
    PARAM_CHECK_FAIL(1002,"参数校验失败");

    private int code;
    private String msg;

    APIResult(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
