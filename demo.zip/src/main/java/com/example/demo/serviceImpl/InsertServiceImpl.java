package com.example.demo.serviceImpl;

import com.example.demo.exception.APIException;
import com.example.demo.mapper.UserMapper;
import com.example.demo.model.User;
import com.example.demo.service.InsertService;
import com.example.demo.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;

/**
 * @program: demo
 * @description: 批量事务测试
 * @author: colins
 * @create: 2020-12-04 09:56
 **/
@Service
public class InsertServiceImpl implements InsertService {
    @Autowired
    private PlatformTransactionManager platformTransactionManager;

    @Autowired
    private TransactionDefinition transactionDefinition;
    @Autowired
    private UserMapper userMapper;
    @Override
    public ResultVO listInsertDemo() {
        for (int i=1;i<=2;i++){
            TransactionStatus transactionStatus = platformTransactionManager.getTransaction(transactionDefinition);
            try{
                for (int z=0;z<10;z++){
                    User user=new User();
                    user.setName("test");
                    userMapper.insertData(user);
//                    if(z==9){
//                        throw new APIException("插入出错");
//                    }
                }
                platformTransactionManager.commit(transactionStatus);
            }catch (Exception e){
                System.out.println("出错了");
                platformTransactionManager.rollback(transactionStatus);
            }

        }
        return new ResultVO();
    }
}
