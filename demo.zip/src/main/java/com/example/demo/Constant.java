package com.example.demo;

import java.util.HashMap;
import java.util.Map;

public class Constant {
    /**
     * 权限管理
     */
    public static Map<Integer,String[]> permission=new HashMap<>();
    static {
        String[] frist={"test","test1"};//用户1所拥有的模块权限  这里的test是模块URL入口  例如：test模块下所有URL都是/test/**
        String[] second={"test"};//用户2所拥有的URL权限
        permission.put(1,frist); //这里的1其实是用户对应ID为1的角色
        permission.put(2,second);//这个2同理

    }
//    static {
//        String[] frist={"insert","delete","select","update"};//用户1所拥有的操作权限
//        String[] second={"insert","select","update"};//用户2所拥有的URL权限
//        String[] third={"select"};//用户3所拥有的URL权限
//        permission.put(1,frist);
//        permission.put(2,second);
//        permission.put(3,third);
//
//    }
//    static {
//        String[] frist={"/url1","/url2","/url3","/url4","/url5","/url6","/url7"};//用户1所拥有的URL权限
//        String[] second={"/url1","/url2","/url3","/url4","/url5"};//用户2所拥有的URL权限
//        String[] third={"/url1","/url2","/url3"};//用户3所拥有的URL权限
//        permission.put(1,frist);
//        permission.put(2,second);
//        permission.put(3,third);
//
//    }














    //日志级别
    public static  final Integer LOG_INFO=1;
    public static  final Integer LOG_ERRO=2;

    //请求类型
    public static  final Integer ADD=1;
    public static  final Integer DELETE=2;
    public static  final Integer UPDATE=3;
    public static  final Integer SELECT=4;

}
