package com.example.mq;

import com.example.mq.Utils.MqConsumerUtils;
import com.example.mq.Utils.MqProducerUtils;
import org.apache.rocketmq.client.exception.MQBrokerException;
import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.remoting.exception.RemotingException;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.UnsupportedEncodingException;

@SpringBootTest
class MqApplicationTests {

	@Test
	void contextLoads() throws InterruptedException, RemotingException, UnsupportedEncodingException, MQClientException, MQBrokerException {
	}

}
