package com.elasticsearch.es.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.util.Date;

@Data
@Document(indexName = "tbproduct")
public class TbProduct {
    @Id
    private Integer id;
    @Field(type = FieldType.Auto)
    private String mainType;
    @Field(type = FieldType.Auto)
    private String subType;
    @Field(type = FieldType.Auto)
    private String docUrl;
    @Field(type = FieldType.Auto)
    private String picUrl;
    @Field(type = FieldType.Auto,analyzer = "ik_smart",searchAnalyzer = "ik_max_word")
    private String name;
    @Field(type = FieldType.Auto)
    private String brand;
    @Field(type = FieldType.Auto)
    private String model;
    @Field(type = FieldType.Auto)
    private String produceArea;
    @Field(type = FieldType.Auto)
    private String appScenarios;
    @Field(type = FieldType.Auto)
    private String price;
    @Field(type = FieldType.Auto)
    private String qualityLevel;
    @Field(type = FieldType.Auto)
    private String company;
    @Field(type = FieldType.Auto)
    private String saleVolume;
    @Field(type = FieldType.Auto)
    private String stock;
    @Field(type = FieldType.Auto)
    private String productTime;
    @Field(type = FieldType.Auto)
    private String supplierName;
    @Field(type = FieldType.Auto)
    private String supplierWeb;
    @Field(type = FieldType.Auto)
    private Date updateTime;


}