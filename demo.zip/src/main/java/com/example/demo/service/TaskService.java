package com.example.demo.service;

public interface TaskService {
    void test1();

    void test2();

    void test3();

    void test4();

    void test5();

    void test6();
}
