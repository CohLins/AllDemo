package com.example.demo.controller;

import com.example.demo.mapper.UserMapper;
import com.example.demo.model.Product;
import com.example.demo.model.User;
import com.example.demo.utils.E3Result;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.atomic.AtomicInteger;

@RestController
@RequestMapping(value = "/test")
public class PressureController {

    @Autowired
    private UserMapper userMapper;

    @RequestMapping(value = "/update")
    public E3Result update(Integer id){
        Product byId = userMapper.findByIdProduct(id);
        byId.setNum(byId.getNum()-1);
        int i = userMapper.updateByIdProduct(byId);
        if (i==0){
            System.out.println("更新失败");
        }
        return E3Result.ok(byId);
    }










    @RequestMapping(value = "/select")
    private E3Result select(){
        User byId = userMapper.findById(1);
        return E3Result.ok(byId);
    }

    @RequestMapping(value = "/insert")
    private E3Result insert(){
        User user = new User();
        user.setName("test");
        userMapper.insertData(user);
        return E3Result.ok();
    }


    @RequestMapping(value = "/delete")
    public  E3Result delete(Integer id){
        Integer byId = userMapper.deleteById(id);
        if (byId>0){
            return E3Result.ok(byId);
        }
        return E3Result.build(400,"未抢到");

    }

}
