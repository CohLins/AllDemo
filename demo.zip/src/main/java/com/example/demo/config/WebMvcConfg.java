package com.example.demo.config;

import com.example.demo.interceptor.ApiIdempotentInterceptor;
import com.example.demo.interceptor.BucketInterceptor;
import com.example.demo.interceptor.URLInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfg implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // 接口幂等性拦截器
        registry.addInterceptor(apiIdempotentInterceptor());

        // 令牌桶拦截器 添加拦截器并选择拦截路径
        registry.addInterceptor(bucketInterceptor()).addPathPatterns("/**");

        //权限拦截器
//        registry.addInterceptor(urlInterceptor()).addPathPatterns("/**");
    }
    @Bean
    public BucketInterceptor bucketInterceptor() {
        return new BucketInterceptor();
    }

    @Bean
    public ApiIdempotentInterceptor apiIdempotentInterceptor() {
        return new ApiIdempotentInterceptor();
    }

    @Bean
    public URLInterceptor urlInterceptor(){
        return new URLInterceptor();
    }
}
