package com.elasticsearch.es.mapper;

import com.elasticsearch.es.model.TbProduct;
import com.elasticsearch.es.model.TbProductExample;
import com.elasticsearch.es.model.TbProductWithBLOBs;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TbProductMapper {
    int countByExample(TbProductExample example);

    int deleteByExample(TbProductExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(TbProductWithBLOBs record);

    int insertSelective(TbProductWithBLOBs record);

    List<TbProductWithBLOBs> selectByExampleWithBLOBs(TbProductExample example);

    List<TbProduct> selectByExample(TbProductExample example);

    TbProductWithBLOBs selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") TbProductWithBLOBs record, @Param("example") TbProductExample example);

    int updateByExampleWithBLOBs(@Param("record") TbProductWithBLOBs record, @Param("example") TbProductExample example);

    int updateByExample(@Param("record") TbProduct record, @Param("example") TbProductExample example);

    int updateByPrimaryKeySelective(TbProductWithBLOBs record);

    int updateByPrimaryKeyWithBLOBs(TbProductWithBLOBs record);

    int updateByPrimaryKey(TbProduct record);
}