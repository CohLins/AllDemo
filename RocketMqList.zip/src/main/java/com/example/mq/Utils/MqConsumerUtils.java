//package com.example.mq.Utils;
//
//import lombok.SneakyThrows;
//import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
//import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
//import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
//import org.apache.rocketmq.client.consumer.listener.MessageListenerConcurrently;
//import org.apache.rocketmq.client.exception.MQBrokerException;
//import org.apache.rocketmq.client.exception.MQClientException;
//import org.apache.rocketmq.common.message.MessageExt;
//import org.apache.rocketmq.remoting.exception.RemotingException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Configuration;
//
//import javax.annotation.PostConstruct;
//import java.io.UnsupportedEncodingException;
//import java.util.ArrayList;
//import java.util.List;
//
//@Configuration
//public class MqConsumerUtils {
//    @Autowired
//    private MqProducerUtils mqProducerUtils;
//
//
//    @PostConstruct
//    public static void SyncConsumer1() throws MQClientException {
//        // Instantiate with specified consumer group name.
//        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer("testConsumer1Group");
//
//        // Specify name server addresses.
//        consumer.setNamesrvAddr("192.168.0.109:9876");
//
//        // Subscribe one more more topics to consume.
//        consumer.subscribe("TopicTest", "TagB");
//        // Register callback to execute on arrival of messages fetched from brokers.
//        consumer.registerMessageListener(new MessageListenerConcurrently() {
//
//            @SneakyThrows
//            @Override
//            public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs,
//                                                            ConsumeConcurrentlyContext context) {
//                for (MessageExt ext:msgs){
//                    System.out.printf("%s Receive New Messages: %s %n", "TagB", new String(ext.getBody(),"UTF-8"));
//                }
//                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
//            }
//        });
//
//        //Launch the consumer instance.
//        consumer.start();
//
//        System.out.printf("Consumer Started.%n");
//    }
//
//    @PostConstruct
//    public static void SyncConsumer2() throws MQClientException {
//        // Instantiate with specified consumer group name.
//        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer("testConsumer2Group");
//
//        // Specify name server addresses.
//        consumer.setNamesrvAddr("192.168.0.109:9876");
//
//        // Subscribe one more more topics to consume.
//        consumer.subscribe("TopicTest", "TagA");
//        // Register callback to execute on arrival of messages fetched from brokers.
//        consumer.registerMessageListener(new MessageListenerConcurrently() {
//
//            @SneakyThrows
//            @Override
//            public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs,
//                                                            ConsumeConcurrentlyContext context) {
//                for (MessageExt ext:msgs){
//                    System.out.printf("%s Receive New Messages: %s %n", "TagA", new String(ext.getBody(),"UTF-8"));
//                }
//                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
//            }
//        });
//
//        //Launch the consumer instance.
//        consumer.start();
//
//        System.out.printf("Consumer Started.%n");
//    }
//
//
////    @PostConstruct
////    public void test() throws InterruptedException, RemotingException, UnsupportedEncodingException, MQClientException, MQBrokerException {
////        List<Integer> ftDeviceSleepDatas =new ArrayList<Integer>();
////        for (int i=0;i<10;i++){
////            ftDeviceSleepDatas.add(i);
////        }
////        mqProducerUtils.AsyncProducer();
////    }
//}
