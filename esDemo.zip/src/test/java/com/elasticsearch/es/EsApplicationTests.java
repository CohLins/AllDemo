package com.elasticsearch.es;

import com.elasticsearch.es.model.TbProduct;
import com.elasticsearch.es.model.TbProductWithBLOBs;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;

import java.io.IOException;

@SpringBootTest
class EsApplicationTests {

	@Autowired
	private ElasticsearchRestTemplate elasticsearchTemplate;

	/**
	 * 创建索引
	 */
	@Test
	public void createIndex() {
		// 创建索引，会根据Item类的@Document注解信息来创建
		elasticsearchTemplate.createIndex(TbProductWithBLOBs.class);
//		// 配置映射，会根据Item类中的id、Field等字段来自动完成映射
//		elasticsearchTemplate.putMapping(TbProduct.class);
	}

	/**
	 * 删除索引
	 */
	@Test
	public void deleteIndex() {
		boolean tbproduct = elasticsearchTemplate.deleteIndex("user");
		System.out.println(tbproduct);
	}



}
