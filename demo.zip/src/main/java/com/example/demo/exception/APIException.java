package com.example.demo.exception;

import io.swagger.models.auth.In;

public class APIException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    private String msg;

    public APIException(String msg) {
        super(msg);
        this.msg = msg;
    }

}
