package com.example.demo.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@ApiModel
public class UserHobby {
    @ApiModelProperty("序号ID")
    private Integer id;

    @ApiModelProperty("用户ID")
    private Integer userId;

    @ApiModelProperty("用户爱好")
    private String hobby;

    @ApiModelProperty("爱好描述")
    private String describe;

    @ApiModelProperty("创建时间")
    private Date createTime;

}
