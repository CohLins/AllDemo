package com.example.demo.controller;

import com.example.demo.mapper.UserMapper;
import com.example.demo.model.User;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "用户接口")//对Controller的描述
@Controller
public class UserController
{
    @Autowired
    private UserMapper userMapper;

    @ResponseBody
    @ApiOperation("查询用户及爱好")//对接口的描述
    //请求类型最好是确定用什么请求方式 不然它会列举所有请求方式出来  ps：这里没有确定 下面的确定了看看效果
    @RequestMapping(value = "/more")
    public List<User> more(){//这里返回类型是实体类 详情见实体类配置  传参如果是实体类也是一样的
        List<User> users = userMapper.queryMoreData();
        return users;
    }


    @ApiOperation(value = "测试接口", notes = "此接口描述")//对接口的描述
    @ApiImplicitParams({//对传参的描述 多个参数就有多个@ApiImplicitParam用，隔开
            @ApiImplicitParam(name = "id", value = "用户ID", required = false)
    })
    @GetMapping(value = "/test")
    public String test(String id){
        return id;
    }
}
