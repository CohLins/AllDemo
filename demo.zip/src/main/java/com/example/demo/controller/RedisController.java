package com.example.demo.controller;

import com.example.demo.utils.RedisUtils;
import com.example.demo.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("redis")
@RestController
public class RedisController {
    @Autowired
    private RedisUtils redisUtils;

    @GetMapping("setlist")
    public ResultVO setlist(String value){
        redisUtils.sSet("emilBack",value);
        redisUtils.set(value,value,60);
        return new ResultVO();
    }

    @GetMapping("getlist")
    public ResultVO getlist(String value){
        redisUtils.sSet("emilBack",value);
        redisUtils.set(value,value,60);
        return new ResultVO();
    }
}
