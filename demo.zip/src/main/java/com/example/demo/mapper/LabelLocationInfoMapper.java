package com.example.demo.mapper;

import com.example.demo.model.LabelLocationInfo;
import com.example.demo.model.LabelLocationInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface LabelLocationInfoMapper {
    /**
     * countByExample
     * @param example
     * @return 
     */
    long countByExample(LabelLocationInfoExample example);

    /**
     * deleteByExample
     * @param example
     * @return 
     */
    int deleteByExample(LabelLocationInfoExample example);

    /**
     * deleteByPrimaryKey
     * @param id
     * @return 
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * insert
     * @param record
     * @return 
     */
    int insert(LabelLocationInfo record);

    /**
     * insertSelective
     * @param record
     * @return 
     */
    int insertSelective(LabelLocationInfo record);

    /**
     * selectByExample
     * @param example
     * @return 
     */
    List<LabelLocationInfo> selectByExample(LabelLocationInfoExample example);

    /**
     * selectByPrimaryKey
     * @param id
     * @return 
     */
    LabelLocationInfo selectByPrimaryKey(Integer id);

    /**
     * updateByExampleSelective
     * @param record
     * @param example
     * @return 
     */
    int updateByExampleSelective(@Param("record") LabelLocationInfo record, @Param("example") LabelLocationInfoExample example);

    /**
     * updateByExample
     * @param record
     * @param example
     * @return 
     */
    int updateByExample(@Param("record") LabelLocationInfo record, @Param("example") LabelLocationInfoExample example);

    /**
     * updateByPrimaryKeySelective
     * @param record
     * @return 
     */
    int updateByPrimaryKeySelective(LabelLocationInfo record);

    /**
     * updateByPrimaryKey
     * @param record
     * @return 
     */
    int updateByPrimaryKey(LabelLocationInfo record);
}