//package com.example.mq.Utils;
//
//import org.apache.rocketmq.client.exception.MQBrokerException;
//import org.apache.rocketmq.client.exception.MQClientException;
//import org.apache.rocketmq.client.producer.DefaultMQProducer;
//import org.apache.rocketmq.client.producer.SendCallback;
//import org.apache.rocketmq.client.producer.SendResult;
//import org.apache.rocketmq.common.message.Message;
//import org.apache.rocketmq.remoting.common.RemotingHelper;
//import org.apache.rocketmq.remoting.exception.RemotingException;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import java.io.UnsupportedEncodingException;
//import java.util.concurrent.CountDownLatch;
//import java.util.concurrent.TimeUnit;
//
//@Configuration
//public class MqProducerUtils {
//    /**
//     * 同步发送消息
//     * @throws MQClientException
//     * @throws RemotingException
//     * @throws InterruptedException
//     * @throws MQBrokerException
//     * @throws UnsupportedEncodingException
//     */
//
//    public  void SyncProducer() throws MQClientException, RemotingException, InterruptedException, MQBrokerException, UnsupportedEncodingException {
//        //Instantiate with a producer group name.
//        DefaultMQProducer producer = new
//                DefaultMQProducer("testProducerGroup");
//        // Specify name server addresses.
//        producer.setNamesrvAddr("192.168.0.109:9876");
//        //Launch the instance.
//        producer.start();
//        for (int i = 0; i < 10; i++) {
//            if(i%2==1){
//                Message msg = new Message("TopicTest",
//                        "TagA",
//                        ("Hello RocketMQ "+ i).getBytes(RemotingHelper.DEFAULT_CHARSET) /* Message body */
//                );
//                SendResult sendResult = producer.send(msg);
//                System.out.printf("%s%n", sendResult);
//            }else {
//                Message msg = new Message("TopicTest",
//                        "TagB",
//                        ("Hello RocketMQ "+ i).getBytes(RemotingHelper.DEFAULT_CHARSET) /* Message body */
//                );
//                SendResult sendResult = producer.send(msg);
//                System.out.printf("%s%n", sendResult);
//            }
//        }
//        //Shut down once the producer instance is not longer in use.
//        producer.shutdown();
//    }
//
//    /**
//     * 异步发送消息
//     */
//
//    public void AsyncProducer() throws MQClientException, UnsupportedEncodingException, RemotingException, InterruptedException, MQBrokerException {
//        //Instantiate with a producer group name.
//        DefaultMQProducer producer = new DefaultMQProducer("testProducerGroup");
//        // Specify name server addresses.
//        producer.setNamesrvAddr("192.168.0.121:9876");
//        //Launch the instance.
//        producer.start();
//        producer.setRetryTimesWhenSendAsyncFailed(0);
//
////        int messageCount = 100;
////        final CountDownLatch countDownLatch = new CountDownLatch(messageCount);
//        for (int i = 0; i < 10; i++) {
//            try {
//                final int index = i;
//                Message msg = new Message("TopicTest",
//                        "TagA",
//                        "Hello world".getBytes(RemotingHelper.DEFAULT_CHARSET));
//                producer.send(msg, new SendCallback() {
//                    public void onSuccess(SendResult sendResult) {
////                        countDownLatch.countDown();
//                        System.out.printf("%-10d OK %s %n", index, sendResult.getMsgId());
//                    }
//                    public void onException(Throwable e) {
////                        countDownLatch.countDown();
//                        System.out.printf("%-10d Exception %s %n", index, e);
//                        e.printStackTrace();
//                    }
//                });
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
////        countDownLatch.await(5, TimeUnit.SECONDS);
//        producer.shutdown();
//    }
//    /**
//     * 单向传输
//     */
//
//    public  void OnewayProducer() throws MQClientException, UnsupportedEncodingException, RemotingException, InterruptedException {
//        //Instantiate with a producer group name.
//        DefaultMQProducer producer = new DefaultMQProducer("please_rename_unique_group_name");
//        // Specify name server addresses.
//        producer.setNamesrvAddr("localhost:9876");
//        //Launch the instance.
//        producer.start();
//        for (int i = 0; i < 100; i++) {
//            //Create a message instance, specifying topic, tag and message body.
//            Message msg = new Message("TopicTest" /* Topic */,
//                    "TagA" /* Tag */,
//                    ("Hello RocketMQ " +
//                            i).getBytes(RemotingHelper.DEFAULT_CHARSET) /* Message body */
//            );
//            //Call send message to deliver message to one of brokers.
//            producer.sendOneway(msg);
//        }
//        //Wait for sending to complete
//        Thread.sleep(5000);
//        producer.shutdown();
//    }
//
//}
