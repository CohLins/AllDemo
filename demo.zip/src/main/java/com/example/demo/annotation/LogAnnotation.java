package com.example.demo.annotation;


import com.example.demo.LogRequestTypeEnum;

import java.lang.annotation.*;

//@Documented
//@Inherited
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface LogAnnotation {
    /**
     * 操作类型(enum):添加,删除,修改,登陆
     */
    String requestRemark() ;
}
