package com.example.demo.model;


import io.swagger.models.auth.In;
import lombok.Data;

@Data
public class Product {
    private Integer id;
    private String name;
    private Integer num;
    private Integer version;
}
