package com.example.demo.serviceImpl;

import com.example.demo.exception.APIException;
import com.example.demo.mapper.SysLogErrorMapper;
import com.example.demo.model.SysLogError;
import com.example.demo.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;


@Service
public class TaskServiceImpl implements TaskService {
    @Autowired
    private SysLogErrorMapper sysLogErrorMapper;

    @Override
//    @Transactional
    @Async("taskExecutor")
    public void test1() {
        try {
            Thread.sleep(101);
            System.out.println(string(Thread.currentThread().getName()+1,1000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    @Async("taskExecutor")
    public void test2() {
        try {
            Thread.sleep(102);
            System.out.println(string(Thread.currentThread().getName()+2,2000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Override
    @Async("taskExecutor")
    public void test3() {
        try {
            Thread.sleep(103);
            System.out.println(string(Thread.currentThread().getName()+3,3000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Override
    @Async("taskExecutor")
    public void test4() {
        try {
            Thread.sleep(104);
            System.out.println(string(Thread.currentThread().getName()+4,4000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Override
    @Async("taskExecutor")
    public void test5() {
        try {
            Thread.sleep(105);
            System.out.println(string(Thread.currentThread().getName()+5,5000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Override
    @Async("taskExecutor")
    public void test6() {
        try {
            Thread.sleep(106);
            System.out.println(string(Thread.currentThread().getName()+6,6000));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static String string(String name,Integer limit){
        System.out.println(name+"-->"+limit);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return name+"-->"+limit;
    }
}
