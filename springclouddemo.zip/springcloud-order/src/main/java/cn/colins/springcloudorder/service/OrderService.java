package cn.colins.springcloudorder.service;

import cn.colins.springcloudorder.mdoel.Order;

public interface OrderService {
    Order queryOrderById(String orderId);
}
