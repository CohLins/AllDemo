package com.example.demo.model;

import lombok.Data;

import java.util.List;

@Data
public class ClassBean {
    private Integer id;
    private String teacherName;
    private List<User> users;
}
