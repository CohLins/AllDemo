package com.example.demo.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

@Data
@ApiModel//实体类声明
public class User {
    @ApiModelProperty("用户id")//参数描述
    @NotNull(message = "用户id不能为空")
    private Integer id;

    @ApiModelProperty("用户名字")//参数描述
    private String name;

    @ApiModelProperty("用户性别")//参数描述
    private String sex;

    @ApiModelProperty("用户年龄")//参数描述
    private Integer age;

    @ApiModelProperty("用户城市")//参数描述
    private String city;

    @ApiModelProperty("用户地址")//参数描述
    private String address;

    @ApiModelProperty("用户创建时间")//参数描述
    private Date createTime;

    @ApiModelProperty("用户更新时间")//参数描述
    private Date updateTime;

    @ApiModelProperty("用户图片路径")//参数描述
    private String picUrl;

    private Integer version;


    @ApiModelProperty("用户爱好")//参数描述
    private List<UserHobby> hobbys;
}